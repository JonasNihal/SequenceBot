﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using E_Book_Verleih.Models;



namespace E_Book_Verleih
{
    
    public sealed partial class browseBook : Page
    {
        private Einstellungen settings;
        private ObservableCollection<eBook> eBooks;

        public ObservableCollection<string> filterListe;

       
        public browseBook()
        {
            this.InitializeComponent();
            settings = new Einstellungen();
            eBooks = App.eBooks;
            filterListe = new ObservableCollection<string>();
            filterListe.Add("Ausgeliehen");
            filterListe.Add("Favoriten");
            filterListe.Add(" ");
        }

        private void Back_Click(object sender, RoutedEventArgs e)
        {
            this.Frame.Navigate(typeof(MainPage));
        }

        private void GridView_ItemClick( object sender , ItemClickEventArgs e)
        {
            
            eBook eBookPara =(eBook)e.ClickedItem;

            if (eBookPara != null)
            {
              
                this.Frame.Navigate(typeof(detailBook), eBookPara);
            }
           
        }

        private void AutoSuggestBox_TextChanged(AutoSuggestBox sender, AutoSuggestBoxTextChangedEventArgs args)
        {
            string querry = SucheLeiste.Text;
            string filter = " ";

            if (Filter.SelectedItem != null)
            {
               filter = Filter.SelectedItem.ToString();
            }
            
            if(filter == " ")
            {
                if (querry.Length >= 3)
                {
                    eBookGrid.ItemsSource = App.eBooks.Where(x => x.Titel.ToUpper().Contains(querry.ToUpper()));
                }
                else
                {
                    eBookGrid.ItemsSource = App.eBooks;
                }
            }
            else if(filter == "Ausgeliehen") 
            {
                if (querry.Length >= 3)
                {
                    eBookGrid.ItemsSource = App.eBooks.Where(x => (x.Titel.ToUpper().Contains(querry.ToUpper())) && x.Ausgeliehen == true);
                }
                else
                {
                    eBookGrid.ItemsSource = App.eBooks.Where(x => x.Ausgeliehen == true);
                }
            }
            else if (filter == "Favoriten")
            {
                if (querry.Length >= 3)
                {
                    eBookGrid.ItemsSource = App.eBooks.Where(x => (x.Titel.ToUpper().Contains(querry.ToUpper())) && x.Favorit == true);
                }
                else
                {
                    eBookGrid.ItemsSource = App.eBooks.Where(x => x.Favorit == true);
                }
            }
        }

        private void Filter_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            string querry = SucheLeiste.Text;
            string filter = " ";

            if (Filter.SelectedItem != null)
            {
                filter = Filter.SelectedItem.ToString();
            }

            if (filter == " ")
            {
                if (querry.Length >= 3)
                {
                    eBookGrid.ItemsSource = App.eBooks.Where(x => x.Titel.ToUpper().Contains(querry.ToUpper()));
                }
                else
                {
                    eBookGrid.ItemsSource = App.eBooks;
                }
            }
            else if (filter == "Ausgeliehen")
            {
                if (querry.Length >= 3)
                {
                    eBookGrid.ItemsSource = App.eBooks.Where(x => (x.Titel.ToUpper().Contains(querry.ToUpper())) && x.Ausgeliehen == true);
                }
                else
                {
                    eBookGrid.ItemsSource = App.eBooks.Where(x => x.Ausgeliehen == true);
                }
            }
            else if (filter == "Favoriten")
            {
                if (querry.Length >= 3)
                {
                    eBookGrid.ItemsSource = App.eBooks.Where(x => (x.Titel.ToUpper().Contains(querry.ToUpper())) && x.Favorit == true);
                }
                else
                {
                    eBookGrid.ItemsSource = App.eBooks.Where(x => x.Favorit == true);
                }
            }

        }
    }
}
