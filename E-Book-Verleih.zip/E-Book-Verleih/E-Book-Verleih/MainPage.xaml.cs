﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using E_Book_Verleih.Models;
using System.Collections.ObjectModel;

namespace E_Book_Verleih
{
    
    public sealed partial class MainPage : Page
    {
        private Einstellungen settings;
        
      
        public MainPage()
        {
            this.InitializeComponent();
            settings = new Einstellungen();
        }

        private  void Test_Click(object sender, RoutedEventArgs e)
        {
            if(username.Text != "" && password.Text != "")
            {
                App.CurrentUser = Benutzer.GetUserServer(username.Text);

                if(App.CurrentUser.Passwort == password.Text)
                {
                    App.eBooks = eBook.GetBooksServer(App.CurrentUser.Id);                    
                    this.Frame.Navigate(typeof(browseBook));
                }
                else
                {
                    warning.Text = "Passwort oder Benutzername falsch!";
                }

                
            }
            else
            {
                warning.Text = "Sie müssen ihren Benutzernamen und ihr Passwort eingeben um fortzufahern!";
            }        
        }
    }
}
