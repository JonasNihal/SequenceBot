﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace E_Book_Verleih.Models
{
    public class Einstellungen
    {
        public Einstellungen()
        {
            InterfaceFarbe = "Navy";
            HintergrundFarbe = "White";
            ButtonFarbe = "MediumBlue";
            TextFarbe1 = "White";
            TextFarbe2 = "Black";
           
        }
        public string InterfaceFarbe { get; set; }

        public string ButtonFarbe { get; set; }

        public string HintergrundFarbe { get; set; }

        public string TextFarbe1 { get; set; }
        public string TextFarbe2 { get; set; }
       
    }
}
