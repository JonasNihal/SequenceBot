﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace E_Book_Verleih.Models
{
    public class eBook
    {
        //Propeties der eBook-Klasse
        public int Id { get; set; }
        public string ISBN { get; set; }
        public string Titel { get; set; }
        public string Beschreibung { get; set; }
        public string Erscheinungsdatum { get; set; }
        public string Autor { get; set; }
        public string Verlag { get; set; }
        public string Bild { get; set; }
        public bool Ausgeliehen { get; set; }
        public bool Favorit { get; set; }

        //Methode um eine Instanz der eBook-Klasse mit Daten vom Server zu bestücken
        public static ObservableCollection<eBook> GetBooksServer(int ku_id)
        {
            var eBooks = new ObservableCollection<eBook>();

            string conectionString = "SERVER=localhost;user id=root ;database=eBookverleih";
            MySqlConnection mysqlcon = new MySqlConnection(conectionString);

            string sqlQuerry = $@"SELECT eb.eb_id AS Id, 
                                eb.isbn AS ISBN, 
                                eb.title AS Titel, 
                                eb.beschreibung AS Beschreibung, 
                                eb.erscheinungsdatum AS Erscheinungsdatum, 
                                CONCAT(au.vorname, ' ', au.nachname) AS Autor , 
                                ve.name AS Verlag, 
                                IF(ISNULL(lv.lv_id) = 0 AND lv.ku_id = {ku_id}, TRUE , FALSE) AS Ausgeliehen,
                                IF(ISNULL(fa.fa_id) = 0 AND fa.ku_id = {ku_id}, TRUE , FALSE) AS Favorit
                                FROM ebook eb
                                LEFT JOIN autor au ON eb.au_id = au.au_id
                                LEFT JOIN verlag ve ON eb.ve_id = ve.ve_id
                                LEFT JOIN leihverzeichnis lv ON eb.eb_id = lv.eb_id 
                                LEFT JOIN favorit fa ON eb.eb_id = fa.eb_id
                                ORDER BY eb.eb_id;";

            MySqlCommand mysqlcom = new MySqlCommand(sqlQuerry, mysqlcon);

            mysqlcon.Open();

            MySqlDataReader mysqlread = mysqlcom.ExecuteReader(CommandBehavior.CloseConnection);

            while (mysqlread.Read())
            {
                bool ausgeliehen = false;

                bool favorisiet = false;

                if (mysqlread["Ausgeliehen"].ToString() == "1")
                {
                    ausgeliehen = true;
                }

                if (mysqlread["Favorit"].ToString() == "1")
                {
                    favorisiet = true;
                }

                string[] datum = (mysqlread["Erscheinungsdatum"].ToString()).Split();

                eBooks.Add(new eBook
                {
                    Id = int.Parse(mysqlread["Id"].ToString()),
                    ISBN = mysqlread["ISBN"].ToString(),
                    Titel = mysqlread["Titel"].ToString(),
                    Beschreibung = mysqlread["Beschreibung"].ToString(),
                    Erscheinungsdatum = datum[0],
                    Autor = mysqlread["Autor"].ToString(),
                    Verlag = mysqlread["Verlag"].ToString(),
                    Bild = $@"Assets/{mysqlread["Id"].ToString()}.png",
                    Ausgeliehen = ausgeliehen,
                    Favorit = favorisiet
                });
            }

            mysqlcon.Close();

            return eBooks;
        }
        //Methode zum Testen wenn Datenbank nicht verfügbar
        public static ObservableCollection<eBook> GetBooksDebug()
        {
            var eBooks = new ObservableCollection<eBook>();

            eBooks.Add(new eBook { Id = 1, ISBN = "1234", Titel = "Harald Töpfer", Beschreibung = "Zauberei und so ein Zeug", Erscheinungsdatum = "01.01.2022", Autor = "J.K. Rollend", Verlag = "Bootleg Verlag", Bild = "Assets/1.png" });
            eBooks.Add(new eBook { Id = 2, ISBN = "1235", Titel = "Der Kerl mit den Ringen", Beschreibung = "voll Episch", Erscheinungsdatum = "01.01.2022", Autor = "das tolle Kind", Verlag = "Bootleg Verlag", Bild = "Assets/2.png" });
            eBooks.Add(new eBook { Id = 3, ISBN = "1236", Titel = "Der Ruf von Kuthtruluu", Beschreibung = "ey voll schwer zu buchstabieren", Erscheinungsdatum = "01.01.2022", Autor = "H.P. Liebeshandwerk", Verlag = "Bootleg Verlag", Bild = "Assets/3.png" });
            eBooks.Add(new eBook { Id = 4, ISBN = "1237", Titel = "Die Farm der Biere", Beschreibung = "Ups, freudscher verleser", Erscheinungsdatum = "01.01.2022", Autor = "Georg Odergut", Verlag = "Bootleg Verlag", Bild = "Assets/4.png" });
            eBooks.Add(new eBook { Id = 5, ISBN = "1238", Titel = "Fuß", Beschreibung = "Iiiie wie das Stinkt", Erscheinungsdatum = "01.01.2022", Autor = "Göde", Verlag = "Bootleg Verlag", Bild = "Assets/5.png" });
            eBooks.Add(new eBook { Id = 6, ISBN = "1239", Titel = "Ein Stück", Beschreibung = "lustige Piraten Abenteuer", Erscheinungsdatum = "01.01.2022", Autor = "Erich Oder", Verlag = "Bootleg Manga", Bild = "Assets/6.png" });

            return eBooks;
        }

        //Methode um den Leih oder Favoriten Status eines eBooks auf dem Server upzudaten
        public static void LeiverzeichnissUpdate( int eb_id ,int ku_id, bool keep)
        {
            

            string conectionString = "SERVER=localhost;user id=root ;database=eBookverleih";
            MySqlConnection mysqlcon = new MySqlConnection(conectionString);

            string sqlQuerry = "";


            if (keep == true)
            {
                sqlQuerry = $@"INSERT INTO leihverzeichnis (eb_id, ku_id)
                                    VALUES ({eb_id},{ku_id});";
            }

            if(keep == false)
            {
                sqlQuerry = $@"DELETE FROM leihverzeichnis
                                    WHERE eb_id={eb_id} AND ku_id={ku_id};";
            }
           
            MySqlCommand mysqlcom = new MySqlCommand(sqlQuerry, mysqlcon);

            mysqlcon.Open();

            mysqlcom.ExecuteNonQuery();

            mysqlcon.Close();
        }

        public static void Favoritupdate(int eb_id, int ku_id, bool keep)
        {


            string conectionString = "SERVER=localhost;user id=root ;database=eBookverleih";
            MySqlConnection mysqlcon = new MySqlConnection(conectionString);

            string sqlQuerry = "";


            if (keep == true)
            {
                sqlQuerry = $@"INSERT INTO favorit (eb_id, ku_id)
                                    VALUES ({eb_id},{ku_id});";
            }

            if (keep == false)
            {
                sqlQuerry = $@"DELETE FROM favorit
                                    WHERE eb_id={eb_id} AND ku_id={ku_id};";
            }

            MySqlCommand mysqlcom = new MySqlCommand(sqlQuerry, mysqlcon);

            mysqlcon.Open();

            mysqlcom.ExecuteNonQuery();

            mysqlcon.Close();
        }

    }

 
}
