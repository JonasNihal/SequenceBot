﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace E_Book_Verleih.Models
{
    public class Benutzer
    {
        public int Id { get; set; }
        public string Usernam { get; set; }
        public string Passwort { get; set; }
        public string Vorname { get; set; }
        public string Nachname { get; set; }
        public string Geburtsdatum { get; set; }
        public string Telefon { get; set; }
        public string Mail { get; set; }
        public string Status { get; set; }
        public string Adresse { get; set; }

        public static Benutzer GetUserServer(string username)
        {
            var user = new Benutzer();

            string conectionString = "SERVER=localhost;user id=root ;database=eBookverleih";
            MySqlConnection mysqlcon = new MySqlConnection(conectionString);

            string sqlQuerry = $@"SELECT 
                                ku.ku_id AS Id,
                                ku.passwort AS Passwort,
                                ku.vorname AS Vorname, 
                                ku.nachname AS Nachname,
                                ku.geburtsdatum AS Geburtsdatum, 
                                ku.tele AS Telefon, 
                                ku.mail AS Mail, 
                                ku.konto_status AS kStatus, 
                                CONCAT(a.straße, ' ', a.hausnummer, ' ', o.plz, ' ', o.name) AS Adresse
                                FROM kunde ku 
                                LEFT JOIN adresse a ON ku.a_id = a.a_id
                                LEFT JOIN ort o ON a.o_id = o.o_id
                                WHERE ku.username = '{username}';"
;

            MySqlCommand mysqlcom = new MySqlCommand(sqlQuerry, mysqlcon);

            mysqlcon.Open();

            MySqlDataReader mysqlread = mysqlcom.ExecuteReader(CommandBehavior.CloseConnection);

            while (mysqlread.Read())
            {
                user.Id = int.Parse(mysqlread["Id"].ToString());

                user.Usernam = username;

                user.Passwort = mysqlread["Passwort"].ToString();

                user.Vorname = mysqlread["Vorname"].ToString();

                user.Nachname = mysqlread["Nachname"].ToString();

                user.Geburtsdatum = mysqlread["Geburtsdatum"].ToString();

                user.Telefon = mysqlread["Telefon"].ToString();

                user.Mail = mysqlread["Mail"].ToString();

                user.Status = mysqlread["kStatus"].ToString();

                user.Adresse = mysqlread["Adresse"].ToString();

            }

            mysqlcon.Close();

            return user;
        }


    }       

}




